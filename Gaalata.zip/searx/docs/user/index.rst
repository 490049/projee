==================
User documentation
==================

.. toctree::
   :maxdepth: 2
   :caption: Contents

   search_syntax
   own-instance
